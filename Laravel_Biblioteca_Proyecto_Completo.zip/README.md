# Examen Laravel - Sistema de Biblioteca

Tema: Sistema de Biblioteca

Tablas independientes:
- libros
- autores

## Instalación
composer create-project laravel/laravel examenLaravel
Copiar los archivos de este proyecto.
Configurar .env
php artisan migrate
php artisan serve
