<?php
Schema::create('autores', function (Blueprint $table) {
    $table->id();
    $table->string('nombre');
    $table->string('apellido');
    $table->string('nacionalidad');
    $table->timestamps();
});
