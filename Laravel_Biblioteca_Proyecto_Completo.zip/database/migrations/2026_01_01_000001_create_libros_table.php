<?php
Schema::create('libros', function (Blueprint $table) {
    $table->id();
    $table->string('titulo');
    $table->string('editorial');
    $table->integer('anio_publicacion');
    $table->timestamps();
});
